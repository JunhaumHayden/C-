#include "utils.h"

namespace ods {

int hashCode(int x) {
	return x;
}

}
