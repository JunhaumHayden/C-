/*
 * ChainedHashTable.cpp
 *
 *  Created on: 2011-11-30
 *      Author: morin
 */

#include "ChainedHashTable.h"

namespace ods {


template class ChainedHashTable<int>;

} /* namespace ods */
