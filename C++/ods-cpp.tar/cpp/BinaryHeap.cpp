/*
 * BinaryHeap.cpp
 *
 *  Created on: 2011-11-30
 *      Author: morin
 */

#include "BinaryHeap.h"

namespace ods {

} /* namespace ods */
