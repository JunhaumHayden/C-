/*
 * BinaryTree.cpp
 *
 *  Created on: 2011-11-28
 *      Author: morin
 */

#include "BinaryTree.h"

namespace ods {


} /* namespace ods */
