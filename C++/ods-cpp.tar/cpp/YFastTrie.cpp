/*
 * YFastTrie.cpp
 *
 *  Created on: 2012-01-27
 *      Author: morin
 */

#include "YFastTrie.h"

namespace ods {


} /* namespace ods */
