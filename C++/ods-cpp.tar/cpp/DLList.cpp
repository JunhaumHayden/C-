/*
 * DLList.cpp
 *
 *  Created on: 2011-11-24
 *      Author: morin
 */

#include "DLList.h"

namespace ods {


template DLList<int>::DLList();
template DLList<int>::~DLList();

} /* namespace ods */
