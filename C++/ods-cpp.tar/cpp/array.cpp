/*
 * array.cpp
 *
 *  Created on: 2011-11-24
 *      Author: morin
 */

#include "array.h"

namespace ods {

} /* namespace ods */
