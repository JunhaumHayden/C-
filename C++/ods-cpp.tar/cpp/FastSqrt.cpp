/*
 * FastSqrt.cpp
 *
 *  Created on: 2011-11-25
 *      Author: morin
 */

#include "FastSqrt.h"

namespace ods {


} /* namespace ods */
