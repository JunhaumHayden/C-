/*
 * BlockStore.cpp
 *
 *  Created on: 2013-07-03
 *      Author: morin
 */

#include "BlockStore.h"

namespace ods {


} /* namespace ods */
