/*
 * XFastTrie.cpp
 *
 *  Created on: 2012-01-26
 *      Author: morin
 */

#include "XFastTrie.h"

namespace ods {


} /* namespace ods */
